# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Artifacts

### ProdLi Chrome Extension (`artifacts/prodli/`)
A Neobrutalism-styled Chrome extension that replaces the new tab page with a productivity hub.

**Sections:**
- **Editor** — TipTap rich text editor with formatting toolbar, multiple notes, auto-save, word/char count
- **To-Dos** — Task manager with subtasks, priorities, due dates, drag-to-reorder (@dnd-kit), filters
- **Pomodoro** — Configurable timer with SVG progress ring, session log, desktop notifications, audible chime
- **Habit Tracker** — Daily habits with streaks, 35-day heatmaps, emoji/color icons, archive support

**Key files:**
- `artifacts/prodli/src/App.tsx` — Main nav shell with section routing + live clock
- `artifacts/prodli/src/sections/` — Individual section components
- `artifacts/prodli/src/lib/storage.ts` — Chrome storage API abstraction (falls back to localStorage in dev)
- `artifacts/prodli/src/types.ts` — Shared TypeScript types
- `artifacts/prodli/extension/manifest.json` — Chrome Extension MV3 manifest
- `artifacts/prodli/build-extension.mjs` — Extension packaging script
- `artifacts/prodli/README.md` — Chrome Web Store submission guide

**Build for Chrome:**
```
pnpm --filter @workspace/prodli run build:extension
```
Outputs `artifacts/prodli/dist-extension/` (load unpacked) **and** `artifacts/prodli/prodli-extension.zip` (upload to Web Store).

**Design:** Neobrutalism — thick black borders, offset box-shadows, bold uppercase typography, Space Grotesk font, high-contrast yellow/cyan/red/green accents

### Chrome Web Store Submission Checklist

1. Run `pnpm --filter @workspace/prodli run build:extension` from the repo root
2. Confirm `artifacts/prodli/prodli-extension.zip` was created
3. Go to [https://chrome.google.com/webstore/devconsole/](https://chrome.google.com/webstore/devconsole/)
4. Click **New item** and upload `prodli-extension.zip`
5. Fill in store listing: title, description, category (Productivity), screenshots (1280×800 or 640×400), and a 128×128 icon
6. Set **Visibility** (Public or Unlisted) and submit for review

> All data is stored in `chrome.storage.local` — no backend, no server, no account required.

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

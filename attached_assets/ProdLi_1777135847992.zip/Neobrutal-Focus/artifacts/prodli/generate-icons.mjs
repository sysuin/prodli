/**
 * ProdLi Icon Generator
 *
 * Converts extension/icons/icon.svg into PNG files at 16, 48, and 128px.
 *
 * Run from repo root:   pnpm --filter @workspace/prodli run build:icons
 * Run from package dir: node generate-icons.mjs
 *
 * Requires: @resvg/resvg-js (WASM-based SVG renderer, no native compilation)
 */
import { Resvg } from "@resvg/resvg-js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SVG_PATH = path.join(__dirname, "extension", "icons", "icon.svg");
const ICONS_DIR = path.join(__dirname, "extension", "icons");

const svgContent = fs.readFileSync(SVG_PATH, "utf-8");

const SIZES = [16, 48, 128];

console.log("Generating ProdLi extension icons from icon.svg...\n");

for (const size of SIZES) {
  const resvg = new Resvg(svgContent, {
    fitTo: { mode: "width", value: size },
  });
  const rendered = resvg.render();
  const buffer = rendered.asPng();
  const outPath = path.join(ICONS_DIR, `icon-${size}.png`);
  fs.writeFileSync(outPath, buffer);
  console.log(`  ✅ icon-${size}.png  (${size}×${size}px, ${buffer.length} bytes)`);
}

console.log("\nDone. Icon files are in extension/icons/");

/**
 * ProdLi Chrome Extension Build Script
 *
 * Run from repo root:      node artifacts/prodli/build-extension.mjs
 * Run via npm script:      pnpm --filter @workspace/prodli run build:extension
 * Run from package dir:    node build-extension.mjs
 *
 * This script:
 * 1. Builds the Vite app using the pnpm workspace filter (works from any directory)
 * 2. Copies manifest.json and icons into the output
 * 3. Produces dist-extension/ — ready to load unpacked in Chrome
 * 4. Zips dist-extension/ into prodli-extension.zip — ready for Web Store upload
 */
import { execSync } from "child_process";
import fs from "fs";
import { createWriteStream } from "fs";
import path from "path";
import { fileURLToPath } from "url";
import archiver from "archiver";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Resolve paths relative to this script (works from any cwd)
const DIST = path.join(__dirname, "dist-extension");
const MANIFEST = path.join(__dirname, "extension", "manifest.json");
const ICONS = path.join(__dirname, "extension", "icons");
const REPO_ROOT = path.resolve(__dirname, "..", "..");

// Clean up
if (fs.existsSync(DIST)) {
  fs.rmSync(DIST, { recursive: true });
}
fs.mkdirSync(DIST, { recursive: true });

console.log("Building ProdLi for Chrome extension...");
console.log("Repo root:", REPO_ROOT);
console.log("Package dir:", __dirname);

// Build using pnpm workspace filter — works from any directory in the repo
execSync("pnpm --filter @workspace/prodli run build", {
  stdio: "inherit",
  cwd: REPO_ROOT,
  env: {
    ...process.env,
    // Vite config reads these from env; provide defaults if not set
    PORT: process.env.PORT || "3000",
    BASE_PATH: "/",
    NODE_ENV: "production",
  },
});

// Copy built files from dist/public to dist-extension/
const BUILT = path.join(__dirname, "dist", "public");
if (!fs.existsSync(BUILT)) {
  throw new Error(`Build output not found at ${BUILT}. Check Vite build succeeded.`);
}
fs.cpSync(BUILT, DIST, { recursive: true });

// Copy manifest.json
fs.copyFileSync(MANIFEST, path.join(DIST, "manifest.json"));

// Copy icons
const iconsDest = path.join(DIST, "icons");
fs.mkdirSync(iconsDest, { recursive: true });
if (fs.existsSync(ICONS)) {
  fs.cpSync(ICONS, iconsDest, { recursive: true });
}

// Verify index.html exists
const indexPath = path.join(DIST, "index.html");
if (!fs.existsSync(indexPath)) {
  const files = fs.readdirSync(DIST);
  console.warn("⚠️  index.html not found in dist-extension/. Files present:", files);
} else {
  console.log("✅  index.html found");
}

// List final files
const extensionFiles = fs.readdirSync(DIST);
console.log("\nExtension files:", extensionFiles);
console.log(`\n✅ Unpacked extension ready at: ${DIST}`);

// Create ZIP for Chrome Web Store submission
const ZIP_PATH = path.join(__dirname, "prodli-extension.zip");
if (fs.existsSync(ZIP_PATH)) fs.rmSync(ZIP_PATH);
console.log("\nCreating prodli-extension.zip...");
await new Promise((resolve, reject) => {
  const output = createWriteStream(ZIP_PATH);
  const archive = archiver("zip", { zlib: { level: 9 } });
  output.on("close", resolve);
  archive.on("error", reject);
  archive.pipe(output);
  archive.directory(DIST, false);
  archive.finalize();
});
const zipSizeMb = (fs.statSync(ZIP_PATH).size / 1024 / 1024).toFixed(2);
console.log(`✅ ZIP created at: ${ZIP_PATH} (${zipSizeMb} MB)`);

// Summary
console.log("\n──────────────────────────────────────────");
console.log("To load unpacked in Chrome (dev / testing):");
console.log("  1. Open chrome://extensions/");
console.log("  2. Enable 'Developer mode' (top right toggle)");
console.log("  3. Click 'Load unpacked' → select dist-extension/");
console.log("\nTo submit to the Chrome Web Store:");
console.log("  1. Go to https://chrome.google.com/webstore/devconsole/");
console.log("  2. Click 'New item'");
console.log("  3. Upload prodli-extension.zip");
console.log("──────────────────────────────────────────");

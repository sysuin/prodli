# ProdLi Chrome Extension

A distraction-free new tab productivity hub with Neobrutalism design.

## Features

- **Editor** — Rich text editor with TipTap. Bold, italic, underline, headings, lists, code blocks, links. Multiple named notes with auto-save and word/character count.
- **To-Dos** — Task manager with priorities (High/Medium/Low), due dates, subtasks, drag-to-reorder, and filters.
- **Pomodoro** — Configurable Pomodoro timer with visual progress ring, session log, desktop notifications, and audible chime.
- **Habit Tracker** — Track daily habits with streaks, 35-day heatmap, emoji/color icons, and completion stats.

All data is stored locally in Chrome's storage — no account or server required.

## Development

```bash
pnpm install
pnpm dev   # Start dev server at localhost
```

## Build for Chrome Web Store

```bash
pnpm build           # Build the Vite app
node build-extension.mjs  # Package as Chrome extension
```

This creates `dist-extension/` — a valid unpacked Chrome extension.

## Load Unpacked in Chrome (Development)

1. Run `pnpm build && node build-extension.mjs`
2. Open `chrome://extensions/`
3. Enable **Developer mode** (toggle top-right)
4. Click **Load unpacked**
5. Select the `dist-extension/` folder
6. Open a new tab — ProdLi appears!

## Publish to Chrome Web Store

1. Build the extension: `pnpm build && node build-extension.mjs`
2. Zip the `dist-extension/` folder
3. Visit [Chrome Web Store Developer Console](https://chrome.google.com/webstore/devconsole/)
4. Click **New item** → upload the zip
5. Fill in store listing: description, screenshots, category (Productivity)
6. Pay the $5 one-time developer fee (if not done yet)
7. Submit for review (usually 1-3 business days)

## Required Chrome Web Store Assets

- **Icon**: 128×128px PNG (provided in `extension/icons/`)
- **Screenshots**: At least 1 screenshot (1280×800 or 640×400)
- **Description**: See the manifest.json description field
- **Category**: Productivity

## Icons

Icons are SVG files in `extension/icons/`. To generate PNG versions for the Chrome Web Store:

```bash
# Using Inkscape (if installed)
inkscape icon.svg --export-png=icon-16.png -w 16 -h 16
inkscape icon.svg --export-png=icon-48.png -w 48 -h 48
inkscape icon.svg --export-png=icon-128.png -w 128 -h 128
```

Or use any online SVG-to-PNG converter.

## Tech Stack

- React 19 + Vite (TypeScript)
- TipTap (rich text editor)
- @dnd-kit (drag and drop)
- Tailwind CSS v4
- Chrome Extension Manifest V3
- chrome.storage.local (data persistence)
